"use client";

import { useCallback, useState } from "react";

import { DateCalendar } from "@mui/x-date-pickers";
import { PickerSelectionState } from "@mui/x-date-pickers/internals";
import { ChevronLeft, ChevronRight, CalendarMonth } from "@mui/icons-material";
import { IconButton, Popover, Typography } from "@mui/material";
import dayjs, { Dayjs } from "dayjs";
import localizedFormats from "dayjs/plugin/localizedFormat";

dayjs.extend(localizedFormats);

const WEEKDAY_FORMATTER = new Intl.DateTimeFormat("en-US", {
  weekday: "long",
});

const SAME_YEAR_FORMATTER = new Intl.DateTimeFormat("en-US", {
  day: "numeric",
  month: "long",
});

const OTHER_YEAR_FORMATTER = new Intl.DateTimeFormat("en-US", {
  day: "numeric",
  month: "long",
  year: "numeric",
});

export function getLabel(day: Dayjs) {
  const today = dayjs();

  if (day.isSame(today, "day")) {
    return "Today";
  }

  const yesterday = today.subtract(1, "day");
  if (day.isSame(yesterday, "day")) {
    return "Yesterday";
  }

  if (day.isSame(today, "week")) {
    return WEEKDAY_FORMATTER.format(day.toDate());
  }

  if (day.isSame(today, "year")) {
    return SAME_YEAR_FORMATTER.format(day.toDate());
  }

  return OTHER_YEAR_FORMATTER.format(day.toDate());
}

export default function DayNavigator({
  selectedDay,
  onSelectDay,
  disableFuture,
}: {
  selectedDay: Dayjs;
  onSelectDay: (day: Dayjs) => void;
  disableFuture?: boolean;
}) {
  const today = dayjs();
  const [anchorEl, setAnchorEl] = useState<HTMLButtonElement | null>(null);

  const openDatePicker = (event: React.MouseEvent<HTMLButtonElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const closeDatePicker = useCallback(() => {
    setAnchorEl(null);
  }, [setAnchorEl]);

  const selectPreviousDay = useCallback(() => {
    onSelectDay(selectedDay.subtract(1, "day"));
  }, [selectedDay, onSelectDay]);

  const selectNextDay = useCallback(() => {
    onSelectDay(selectedDay.add(1, "day"));
  }, [selectedDay, onSelectDay]);

  const handleChange = useCallback(
    (value: Dayjs | null, state: PickerSelectionState | undefined) => {
      if (state === "finish") {
        if (value) {
          onSelectDay(value);
        }
      }
    },
    [onSelectDay]
  );

  const label = getLabel(selectedDay);
  const isToday = selectedDay.isSame(today, "day");

  return (
    <div className="flex flex-row items-center">
      <IconButton aria-label="previous day" onClick={selectPreviousDay}>
        <ChevronLeft />
      </IconButton>
      <div className="flex flex-row items-center mx-2">
        <Typography variant="h5" data-testid="current-day-label">
          {label}
        </Typography>
        <IconButton
          sx={{ marginLeft: 1 }}
          onClick={openDatePicker}
          aria-label="open date picker"
        >
          <CalendarMonth />
        </IconButton>
        <Popover
          open={!!anchorEl}
          onClose={closeDatePicker}
          anchorEl={anchorEl}
          anchorOrigin={{
            vertical: "bottom",
            horizontal: "left",
          }}
        >
          <DateCalendar
            value={selectedDay}
            onChange={handleChange}
            disableFuture={disableFuture}
          />
        </Popover>
      </div>
      <IconButton
        aria-label="next day"
        onClick={selectNextDay}
        disabled={isToday && disableFuture}
      >
        <ChevronRight />
      </IconButton>
    </div>
  );
}
