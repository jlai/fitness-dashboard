"use client";

import { atomEffect } from "jotai-effect";
import { toast } from "mui-sonner";

import { FITBIT_API_PROXY_URL, FITBIT_API_URL } from "@/config";
import { isAPIProxyAllowed } from "@/storage/settings";

import { getFreshAccessToken } from "./auth";

const RATE_LIMIT_EXCEEDED_EVENT_TYPE = "fitbitratelimitexceeded";

export interface ErrorResponseBody {
  errors: Array<{
    errorType: string;
    fieldName: string;
    message: string;
  }>;
}

export interface ServerError extends Error {
  status: Response["status"];
  errors?: ErrorResponseBody["errors"];
  errorText?: string;
}

export interface MakeRequestOptions {
  // Fitbit API sometimes throws spurious 502 errors on delete, e.g.
  // https://community.fitbit.com/t5/Web-API-Development/deletion-of-water-records-502-error/td-p/5786102
  ignore502?: boolean;
}

/**
 * Make a request to the Fitbit API.
 */
export async function makeRequest(
  uri: string,
  options?: RequestInit & MakeRequestOptions
) {
  const startTime = Date.now();
  const authToken = await getFreshAccessToken();

  // Use backend proxy instead of direct Fitbit API calls
  const baseUrl = typeof window !== 'undefined' 
    ? window.location.origin 
    : process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000';
  
  const url = new URL('/api/fitbit/proxy', baseUrl);
  url.searchParams.set('path', uri);

  const method = options?.method || 'GET';

  const response = await fetch(url, {
    method,
    headers: {
      "Accept-Language": "metric",
      ...options?.headers,
      Authorization: `Bearer ${authToken}`,
    },
    body: options?.body,
  });

  if (!response.ok) {
    if (response.status === 429) {
      window.dispatchEvent(new CustomEvent(RATE_LIMIT_EXCEEDED_EVENT_TYPE));
    }

    if (options?.ignore502 && response.status === 502) {
      return response;
    }

    const errors = await extractErrors(response);
    const errorText = errors
      ? errors.map((error: any) => error.message).join(" ")
      : undefined;

    const err = new Error(
      `server response (${response.status}): ${
        errorText || response.statusText
      }`
    ) as ServerError;

    err.status = response.status;
    err.errors = errors;
    err.errorText = errorText;

    throw err;
  }

  return response;
}

/** Watch for localStorage changes from other windows. */
export const warnOnRateLimitExceededEffect = atomEffect((get, set) => {
  let lastWarning = 0;

  // Events fired from dispatchEvent
  const listener = () => {
    if (Date.now() - lastWarning > 60 * 1000) {
      toast.error("Fitbit API rate limit exceeded");
      lastWarning = Date.now();
    }
  };

  window.addEventListener(RATE_LIMIT_EXCEEDED_EVENT_TYPE, listener);

  return () => {
    window.removeEventListener(RATE_LIMIT_EXCEEDED_EVENT_TYPE, listener);
  };
});

/**
 * Extract error messages from response body.
 * See https://dev.fitbit.com/build/reference/web-api/troubleshooting-guide/error-handling/
 */
export async function extractErrors(response: Response) {
  try {
    const text = await response.text();
    
    // Try to parse as JSON first
    try {
      const json = JSON.parse(text);
      return json.errors;
    } catch (parseError) {
      // If not JSON, return the text as error message
      return [{ message: text, errorType: 'unknown', fieldName: 'unknown' }];
    }
  } catch (error: any) {
    return [{ message: 'Failed to read error response', errorType: 'unknown', fieldName: 'unknown' }];
  }
}
